
import sun.applet.Main;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;

import java.io.*;
import javax.imageio.*;
import java.util.*;
import java.awt.Component;

public class MainFrame extends JFrame implements MouseListener,MouseMotionListener {
	JMenuBar mb;
    JMenu fileMenu;
    JMenuItem openItem;
    JMenuItem saveItem;
    JMenuItem clearItem;
    JMenuItem exitItem;
    JMenuItem testItem;
    
    JMenu editMenu;      //编辑菜单
    JMenuItem addItem;   //图像加运算
    JMenuItem Item1;     //菜单一
	JMenuItem ItemHrotate;  //双线性插值法旋转
    JMenuItem Item2;     //菜单二
	JMenuItem ItemShrinkage;   //对图片进行放缩
	JMenuItem ItemHShrinkage;  //利用双线性插值对图像进行放缩
	JMenuItem ItemExpose;     //二次曝光
	JMenuItem ItemCutout;    //抠图
	JMenuItem ItemCutgreen;   //抠掉绿色
	JMenuItem ItemLightgreen;  //去掉光照绿幕
    JMenuItem ItemHeighten;   //线性增强
	JMenuItem ItemLog;   //对数增强
	JMenuItem ItemMici;   //幂次变换
	JMenuItem ItemHistogram;  //直方图均衡化
	JMenuItem ItemAverage;//算数均值滤波
	JMenuItem ItemMid;  //中值滤波
	JMenuItem ItemLaplaceEdge;//拉普拉斯实现边缘提取
	JMenuItem ItemLaplaceSharpen; //拉普拉斯实现边缘锐化
	JMenuItem ItemCommonEdge;  //通用边缘提取
	JMenuItem ItemVector;  //矢量中值滤波
            
    //JToolBar tb;
    //JButton newBtn;
    //JButton openBtn;
    //JButton saveBtn;
    
    
    ImagePanel imagePanel;
    ImagePanel imageLabel;
    JScrollPane scrollPane;
    ImageIcon imageIcon;
    BufferedImage rightImage,leftImage;
    
    JFileChooser chooser;
    ImagePreviewer imagePreviewer;
    ImageFileView fileView;
    
    ImageFileFilter bmpFilter;
    ImageFileFilter jpgFilter;
	ImageFileFilter gifFilter;
	ImageFileFilter bothFilter;
	Graphics graphics;

	MouseEvent mouseEvent;
	    
    public MainFrame() {
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                exit(e);
            }
        });

        initComponents();

    }
    
    private void initComponents() {
    	Container contentPane = getContentPane();
    	
    	JSplitPane splitPane=new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
    	
    	imagePanel = new ImagePanel(rightImage);
        scrollPane = new JScrollPane(imagePanel);


       
        imageLabel=new ImagePanel(leftImage);

        
        splitPane.setLeftComponent(new JScrollPane(imageLabel));
    	splitPane.setRightComponent(scrollPane);
        contentPane.add(splitPane, BorderLayout.CENTER);
        
        chooser = new JFileChooser();
        imagePreviewer = new ImagePreviewer(chooser);
        fileView = new ImageFileView();
	    bmpFilter = new ImageFileFilter("bmp", "BMP Image Files");
	    jpgFilter = new ImageFileFilter("jpg", "JPEG Compressed Image Files");
		gifFilter = new ImageFileFilter("gif", "GIF Image Files");
		bothFilter = new ImageFileFilter(new String[] {"bmp", "jpg", "gif"}, "BMP, JPEG and GIF Image Files");
	    chooser.addChoosableFileFilter(jpgFilter);
	    chooser.addChoosableFileFilter(gifFilter);
	    chooser.addChoosableFileFilter(bmpFilter);
        chooser.addChoosableFileFilter(bothFilter);
        chooser.setAccessory(imagePreviewer);
        chooser.setFileView(fileView);
        chooser.setAcceptAllFileFilterUsed(false);
         
              
		//----菜单条------------------------------------------------------------
		mb = new JMenuBar();
		setJMenuBar(mb);
		//----File菜单----------------------------------------------------------
		fileMenu = new JMenu("文件(F)");
		//fileMenu.setIcon(fileIcon);
		fileMenu.setMnemonic('F');
		mb.add(fileMenu);
		
		//newItem = new JMenuItem("新建(N)");
		//newItem.setMnemonic('N');
		//newItem.setAccelerator(KeyStroke.getKeyStroke('N', Event.CTRL_MASK));
		
		openItem = new JMenuItem("打开(O)");
		openItem.setMnemonic('O');
		openItem.setAccelerator(KeyStroke.getKeyStroke('O', Event.CTRL_MASK));
		openItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				openFile(e);
			}
		});
		
		saveItem = new JMenuItem("保存(S)");
		saveItem.setMnemonic('S');
		saveItem.setAccelerator(KeyStroke.getKeyStroke('S', Event.CTRL_MASK));
		saveItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				saveFile(e);
			}
		});
		
		clearItem = new JMenuItem("清除右图(C)");
		clearItem.setMnemonic('C');
		clearItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clear_rImage(e);
			}
		});
		exitItem = new JMenuItem("退出(X)");
		exitItem.setMnemonic('X');

		testItem = new JMenuItem("查看图像的像素值");
		testItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				test_Item(e);
			}
		});
		
		//fileMenu.add(newItem);
		fileMenu.add(openItem);
		fileMenu.add(saveItem);
		fileMenu.add(clearItem);
		fileMenu.addSeparator();
		fileMenu.add(exitItem);
		fileMenu.add(testItem);
		
		//----Edit菜单----------------------------------------------------------
		editMenu = new JMenu("编辑(E)");
		editMenu.setMnemonic('E');
		mb.add(editMenu);
		
		addItem = new JMenuItem("图像加运算(A)");   //, undoIcon);
		addItem.setMnemonic('A');
		addItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				imageAdd(e);       //子菜单处理程序
			}
		});
		
		Item1 = new JMenuItem("旋转(U)");   //, undoIcon);
		Item1.setMnemonic('U');
		//undoItem.setAccelerator(KeyStroke.getKeyStroke('Z', Event.CTRL_MASK));
		Item1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Item1_process(e);
			}
		});

		ItemHrotate = new JMenuItem("高级旋转");
		ItemHrotate.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ItemHrotate_process(e);
			}
		});
		
		Item2 = new JMenuItem("图像反色(R)");   //, redoIcon);
		Item2.setMnemonic('R');
		//redoItem.setAccelerator(KeyStroke.getKeyStroke('Y', Event.CTRL_MASK));
		Item2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Item2_process(e);
			}
		});

		ItemShrinkage = new JMenuItem("图片放缩");
		ItemShrinkage.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ItemShrinkage_process(e);
			}
		});

		ItemHShrinkage = new JMenuItem("对图片进行高级放缩");
		ItemHShrinkage.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ItemHShrinkage_process(e);
			}
		});

		ItemExpose = new JMenuItem("二次曝光");
		ItemExpose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ItemExpose_process(e);
			}
		});

		ItemCutout = new JMenuItem("抠去蓝色");
		ItemCutout.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ItemCutout_process(e);
			}
		});

		ItemCutgreen = new JMenuItem("扣去绿色");
		ItemCutgreen.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ItemCutgreen_process(e);
			}
		});

		ItemLightgreen = new JMenuItem("去除光照绿幕");
		ItemLightgreen.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ItemLightgreen_process(e);
			}
		});

		ItemHeighten = new JMenuItem("图像增强(L)");   //, undoIcon);
		ItemHeighten.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ItemHeighten_process(e);
			}
		});

		ItemLog = new JMenuItem("强调低灰度");
		ItemLog.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
					ItemLog_process(e);
			}
		});

		ItemMici = new JMenuItem("幂次变换");
		ItemMici.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ItemMici_process(e);
			}
		});

		ItemHistogram = new JMenuItem("直方图均衡化");
		ItemHistogram.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ItemHistogram_process(e);
			}
		});

		ItemAverage = new JMenuItem("算数均值滤波");
		ItemAverage.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ItemAverage_process(e);
			}
		});

		ItemMid = new JMenuItem("中值滤波");
		ItemMid.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ItemMid_process(e);
			}
		});

		ItemLaplaceEdge = new JMenuItem("拉普拉斯实现边缘提取");
		ItemLaplaceEdge.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ItemLaplaceEdge_process(e);
			}
		});

		ItemLaplaceSharpen = new JMenuItem("拉普拉斯实现边缘锐化");
		ItemLaplaceSharpen.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ItemLaplaceSharpen_process(e);
			}
		});

		ItemCommonEdge = new JMenuItem("通用边缘提取");
		ItemCommonEdge.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ItemCommonEdge_process(e);
			}
		});

		ItemVector = new JMenuItem("矢量中值滤波");
		ItemVector.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ItemVector_process(e);
			}
		});

		editMenu.add(addItem);
		editMenu.add(Item1);
		editMenu.add(ItemHrotate);
		editMenu.add(Item2);
		editMenu.add(ItemShrinkage);
		editMenu.add(ItemHShrinkage);
		editMenu.add(ItemExpose);
		editMenu.add(ItemCutout);
		//editMenu.add(ItemCutgreen);
		editMenu.add(ItemLightgreen);
		editMenu.add(ItemHeighten);
		editMenu.add(ItemLog);
		editMenu.add(ItemMici);
		editMenu.add(ItemHistogram);
		editMenu.add(ItemAverage);
		editMenu.add(ItemMid);
		editMenu.add(ItemLaplaceEdge);
		editMenu.add(ItemLaplaceSharpen);
		editMenu.add(ItemCommonEdge);
		editMenu.add(ItemVector);

		imageLabel.addMouseListener(this);
		
    }




	private void exit(WindowEvent e) {
        System.exit(0);
    }
    
    void openFile(ActionEvent e) {
    	chooser.setDialogType(JFileChooser.OPEN_DIALOG);
    	if(chooser.showDialog(this, null) == JFileChooser.APPROVE_OPTION) {
    		try { leftImage = ImageIO.read(chooser.getSelectedFile()); }
        	catch(Exception ex) { return ;}
        	//imagePanel.setImage(image);  //
        	imageLabel.setImage(leftImage); //
        	imagePanel.repaint();
        	
    	}
    }
    
    void saveFile(ActionEvent e) {
        	saveFile();
    }
    
    void clear_rImage(ActionEvent e) {
    	
     	imagePanel.setImage(null);
    	imagePanel.repaint();	
    }
      
    void imageAdd(ActionEvent e) {
    	BufferedImage image1=null;
    	
       	chooser.setDialogType(JFileChooser.OPEN_DIALOG);
    	if(chooser.showDialog(this, null) == JFileChooser.APPROVE_OPTION) {
    		try { image1 = ImageIO.read(chooser.getSelectedFile()); }
        	catch(Exception ex) { return ;}
    	}
           	
      	rightImage=EditImage.image_add(leftImage,image1);
    	imagePanel.setImage(rightImage);
    	imagePanel.repaint();
    }

    void test_Item(ActionEvent e){
    	EditImage.testImage(leftImage);
	}
    
    void Item1_process(ActionEvent e) {
		String s;
		float a;
		try {
			s = JOptionPane.showInputDialog("请输入您要输入的旋转度数(0-360): ");
			a = Float.parseFloat(s);
		}catch (NumberFormatException e1){
			JOptionPane.showMessageDialog(this,"请输入正确格式!","提示",0);
			s=JOptionPane.showInputDialog("请输入您要旋转的度数: ");

		}
		a=Float.parseFloat(s);
    	rightImage = EditImage.rotate(leftImage,a);
    	imagePanel.setImage(rightImage);
    	imagePanel.repaint();
    	   	
    
    }

    void ItemHrotate_process(ActionEvent e){
		String s;
		float a;
		try {
			s = JOptionPane.showInputDialog("请输入您要输入的旋转度数(0-360): ");
			a = Float.parseFloat(s);
		}catch (NumberFormatException e1){
			JOptionPane.showMessageDialog(this,"请输入正确格式!","提示",0);
			s=JOptionPane.showInputDialog("请输入您要旋转的度数: ");

		}
		a=Float.parseFloat(s);
		rightImage = EditImage.hrotate(leftImage,a);
		imagePanel.setImage(rightImage);
		imagePanel.repaint();
	}
    
    void Item2_process(ActionEvent e) {

    	rightImage = EditImage.imageOpposite(leftImage);
    	imagePanel.setImage(rightImage);
    	imagePanel.repaint();
    	
    }

    void ItemShrinkage_process(ActionEvent e){
		String s;
		float a;
		try {
			s = JOptionPane.showInputDialog("请输入您放缩的倍数0.1-10: ");
			a = Float.parseFloat(s);
		}catch (NumberFormatException e1){
			JOptionPane.showMessageDialog(this,"请输入正确格式!","提示",0);
			s=JOptionPane.showInputDialog("请输入您放缩的倍数0.1-10: ");

		}
		a=Float.parseFloat(s);
		rightImage = EditImage.shrinkage(leftImage,a);
		imagePanel.setImage(rightImage);
		imagePanel.repaint();
	}

	void ItemHShrinkage_process(ActionEvent e){
		String s;
		float a;
		try {
			s = JOptionPane.showInputDialog("请输入您放缩的倍数0.1-10: ");
			a = Float.parseFloat(s);
		}catch (NumberFormatException e1){
			JOptionPane.showMessageDialog(this,"请输入正确格式!","提示",0);
			s=JOptionPane.showInputDialog("请输入您放缩的倍数0.1-10: ");

		}
		a=Float.parseFloat(s);
		rightImage = EditImage.hshrinkage(leftImage,a);
		imagePanel.setImage(rightImage);
		imagePanel.repaint();
	}

	void ItemExpose_process(ActionEvent e) {
		String s;
		float a;
		BufferedImage image1=null;
		chooser.setDialogType(JFileChooser.OPEN_DIALOG);
		if(chooser.showDialog(this, null) == JFileChooser.APPROVE_OPTION) {
			try { image1 = ImageIO.read(chooser.getSelectedFile()); }
			catch(Exception ex) { return ;}
		}
		try {
			s = JOptionPane.showInputDialog("请输入您要输入的曝光程度(0-1): ");
			a = Float.parseFloat(s);
		}catch (NumberFormatException e1){
			JOptionPane.showMessageDialog(this,"请输入正确格式!","提示",0);
			s=JOptionPane.showInputDialog("请输入您要曝光的程度: ");
		}
		a=Float.parseFloat(s);
		rightImage=EditImage.image_expose(leftImage,image1,a);
		imagePanel.setImage(rightImage);
		imagePanel.repaint();
	}

	void ItemCutout_process(ActionEvent e){
		BufferedImage image1=null;
		chooser.setDialogType(JFileChooser.OPEN_DIALOG);
		if(chooser.showDialog(this, null) == JFileChooser.APPROVE_OPTION) {
			try { image1 = ImageIO.read(chooser.getSelectedFile()); }
			catch(Exception ex) { return ;}
		}
		rightImage=EditImage.image_Cutout(leftImage,image1);
		imagePanel.setImage(rightImage);
		imagePanel.repaint();
	}

	void ItemCutgreen_process(ActionEvent e){
		BufferedImage image1=null;
		chooser.setDialogType(JFileChooser.OPEN_DIALOG);
		if(chooser.showDialog(this, null) == JFileChooser.APPROVE_OPTION) {
			try { image1 = ImageIO.read(chooser.getSelectedFile()); }
			catch(Exception ex) { return ;}
		}
		rightImage=EditImage.image_Cutgreen(leftImage,image1);
		imagePanel.setImage(rightImage);
		imagePanel.repaint();
	}

	void ItemLightgreen_process(ActionEvent e){
		String s;
		float a;
		BufferedImage image1=null;
		try {
			s = JOptionPane.showInputDialog("请输入去绿阈值(建议从0-200,参考值50;数值越大对绿色越敏感): ");
			a = Float.parseFloat(s);
		}catch (NumberFormatException e1){
			JOptionPane.showMessageDialog(this,"请输入正确格式!","提示",0);
			s=JOptionPane.showInputDialog("请输入去绿阈值(建议从0-200,参考值50): ");
		}
		a=Float.parseFloat(s);
    	rightImage=EditImage.lightgreen(a,leftImage);
    	imagePanel.setImage(rightImage);
    	imagePanel.repaint();
	}

	void ItemHeighten_process(ActionEvent e){
        rightImage=EditImage.image_Heighten(leftImage);
        imagePanel.setImage(rightImage);
        imagePanel.repaint();
    }

    void ItemLog_process(ActionEvent e){
		rightImage=EditImage.image_Log(leftImage);
		imagePanel.setImage(rightImage);
		imagePanel.repaint();
	}

	private void ItemMici_process(ActionEvent e) {
		String s;
		float a;
		BufferedImage image1=null;
		try {
			s = JOptionPane.showInputDialog("请输入您变换的幂次变换系数: ");
			a = Float.parseFloat(s);
		}catch (NumberFormatException e1){
			JOptionPane.showMessageDialog(this,"请输入正确格式!","提示",0);
			s=JOptionPane.showInputDialog("请输入您变换的幂次变换系数: ");
		}
		a=Float.parseFloat(s);
		rightImage=EditImage.image_Mici(leftImage,image1,a);
		imagePanel.setImage(rightImage);
		imagePanel.repaint();
	}

	void ItemHistogram_process(ActionEvent e) {
		rightImage=EditImage.image_HistogramHSI(leftImage);
		imagePanel.setImage(rightImage);
		imagePanel.repaint();
	}

	private void ItemAverage_process(ActionEvent e) {
		rightImage=EditImage.average(leftImage);
		imagePanel.setImage(rightImage);
		imagePanel.repaint();
	}

	private void ItemMid_process(ActionEvent e){
		rightImage=EditImage.getMid(leftImage);
		imagePanel.setImage(rightImage);
		imagePanel.repaint();
	}

	private void ItemLaplaceEdge_process(ActionEvent e) {
		rightImage=EditImage.LaplaceEdge(leftImage);
		imagePanel.setImage(rightImage);
		imagePanel.repaint();
	}

	private void ItemLaplaceSharpen_process(ActionEvent e){
    	rightImage=EditImage.LaplaceSharpen(leftImage);
		imagePanel.setImage(rightImage);
		imagePanel.repaint();
	}

	private void ItemCommonEdge_process(ActionEvent e) {
		String s;
		int a;
		BufferedImage image1=null;
		try {
			s = JOptionPane.showInputDialog("请输入您要使用的边缘提取算子(1:Sobel算子;2:Prewitt算子;3:Roberts算子)(1-3)");
			a = (int) Float.parseFloat(s);
		}catch (NumberFormatException e1){
			JOptionPane.showMessageDialog(this,"请输入正确格式!","提示",0);
			s=JOptionPane.showInputDialog("请输入您要使用的边缘提取算子(1:Sobel算子;2:Prewitt算子;3:Roberts算子)(1-3)");
		}
		a=(int)Float.parseFloat(s);
		rightImage=EditImage.CommonEdge(leftImage,a);
		imagePanel.setImage(rightImage);
		imagePanel.repaint();
	}

	private void ItemVector_process(ActionEvent e){
		rightImage=EditImage.VectorMid(leftImage);
		imagePanel.setImage(rightImage);
		imagePanel.repaint();
	}


	private void saveFile() {
		String name = "E:\\"+"反向图片1" + "."
				+ "png";
		System.out.println("save");
		File f=new File(name);
		try {
			ImageIO.write(rightImage,"png",f);
		} catch (FileNotFoundException e1) {
			JOptionPane.showMessageDialog(MainFrame.this, "文件保存出错" + e1.getMessage());
		} catch (IOException e1) {
			e1.printStackTrace();
		} finally {

		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {

	}

	public int sx;
    public int sy;

	@Override
	public void mousePressed(MouseEvent e) {
    	sx=e.getX();
    	sy=e.getY();

	}

	int ex;
	int ey;
	@Override
	public void mouseReleased(MouseEvent e) {
    	 ex= e.getX();
    	 ey= e.getY();
		if (sx>ex){
			int temp=sx;
			sx=ex;
			ex=temp;
		}
		if (sy>ey){
			int temp=sy;
			sy = ey;
			ey=temp;
		}
		graphics=leftImage.getGraphics();
		graphics.setColor(Color.BLACK);
		graphics.drawRect(sx,sy,ex-sx,ey-sy);
		imageLabel.repaint();
    	rightImage=EditImage.saveData(leftImage,sx,sy,ex,ey);
		imagePanel.setImage(rightImage);
		imagePanel.repaint();

	}



	@Override
	public void mouseEntered(MouseEvent e) {

	}

	@Override
	public void mouseExited(MouseEvent e) {

	}

	@Override
	public void mouseDragged(MouseEvent e) {


	}

	@Override
	public void mouseMoved(MouseEvent e) {

	}
}

