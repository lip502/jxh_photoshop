public class test {
    public static void main(String[] args){
        System.out.println("120="+(2*Math.PI)/3);
        System.out.println("240="+(4*Math.PI)/3);
    }
}
